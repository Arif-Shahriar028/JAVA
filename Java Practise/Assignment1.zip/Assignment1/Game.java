import java.lang.Math; 

public class Game {
    // member declarations (private) go here
    private int margin, rating, x, y, z =0;
	private String winner;
	
	
    public Game(String t1,int g1,int b1, String t2, int g2, int b2) {
        // set members here
		setWinner(t1, g1, b1, t2, g2, b2);
        setMargin();
        setRating();
    }
    
    private void setMargin() {
		margin = Math.abs(x-y);
    }
    
    private void setWinner(String t1, int g1, int b1, String t2,  int g2, int b2) {
		x = g1*6+b1;
		y = g2*6+b2;
			
		if(x>y)
			winner = t1;
		else if(x<y)
			winner = t2;
    }
   
    private void setRating(){
		if(x == y)
			rating  = 4;
		else if(margin>=1 && margin<= 6)
			rating = 4;
		else if(margin>=7 && margin<= 24)
			rating = 3;
		else if(margin>=24 && x>100 && y>100)
			rating = 2;
		else
			rating = 1;
    }

    // Getters
    public int margin() {
        return margin;
    }
    
    public String winner() {
        return winner;
    }
    
    public int rating() {
        return rating;
    } 
}

