import java.util.Scanner;

public class Assignment1 {
      public static void main(String[] args) {
		String t1;
        String t2;
	    int g1, b1;
        int g2, b2;
		
	    int i, j, point = 0, bigMargin = 0, smallMargin = Integer.MAX_VALUE, aveMargin = 0;
  
		Scanner sn = new Scanner(System.in);
		
        for(i = 1; i<=5; i++)
		{
			System.out.println("Game "+i+" out of 5");
			point = 0;
			
			t1 = sn.nextLine();
			g1 = sn.nextInt();
			b1 = sn.nextInt();
			sn.nextLine();
			t2 = sn.nextLine();
			g2 = sn.nextInt();
		    b2 = sn.nextInt();
			sn.nextLine();
			
			Game game = new Game(t1, g1, b1, t2, g2, b2);
			System.out.println(t1+"("+g1+" goals, "+b1+" behinds)");
			
			if(game.margin()==0)
			{
				System.out.println("Match drawn: Match rating = "+game.rating());
			}
			else
			{
				System.out.println(game.winner()+" won by "+game.margin()+" points: Match rating = "+game.rating());
			}
				
			if(game.margin()>bigMargin)
				bigMargin = game.margin();
			if(game.margin()<smallMargin)
				smallMargin = game.margin();
			aveMargin = aveMargin + game.margin();
			
		}
		aveMargin = aveMargin /5;
		
        System.out.println("");
		System.out.println("Summary");
		System.out.println("Biggest margin was "+bigMargin);
		System.out.println("Smallest margin was "+smallMargin);
		System.out.println("Average margin was "+aveMargin);    		
           		   
      }
}